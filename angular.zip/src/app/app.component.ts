import { Component, OnInit } from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { GithubApiCallService } from './github-api-call.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  constructor(private githubService: GithubApiCallService) {}
  ngOnInit(): void {}
  myform = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });
  
  organizationList : any = [];
  organzationListData : any;

  userLogin() {
    let userName = this.myform.get('userName').value;
    let password = this.myform.get('password').value;

    // call to api
    this.githubService.login(userName, password).then((resp) => {
     
      this.getOrganizationList()
    }).catch(err =>{
      console.log("Unauthorized");
    });
  }

  getOrganizationList() {

    this.githubService.getListOfOrganization().then((resp) => {
      console.log(resp.Listed_Orgnisations);
      this.organizationList = resp.Listed_Orgnisations;
    });
    
   
  }

  getOrganizationListData(item) {
    let organizationListArray = [item]
    this.githubService.getOrganizationData(organizationListArray).then((resp) => {
      console.log(resp);
      this.organzationListData = JSON.stringify(resp)
    });
  }
}
