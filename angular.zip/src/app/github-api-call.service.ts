import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class GithubApiCallService {
  token = '';
  constructor() {}

  setTokenValue(token) {
    this.token = token;
  }

  makePostRequest(url, requestBody) {
    return fetch(url, {
      method: 'POST',
      body: JSON.stringify(requestBody),
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      },
    })
      .then((resp) => resp.json())
      .catch((err) => {
        return throwError(err);

       
      });
  }
  makeGetRequest(url) {
    return fetch(url, {
     
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${this.token}`
      },
    })
      .then((resp) => resp.json())
      .catch((err) => {
        return throwError(err);
      });
  }

  makeLoginrequest(url, userName,password ) {
    return fetch(url, {
      method: 'POST',
      headers: {
        Authorization: 'Basic ' + btoa(`${userName}:${password}`),
      },
    })
      .then((resp) => resp.json())
      .catch((err) => {
        alert("Invalid password")
      });
  }
  login(userName, password) {
    // post
    let url =
      'https://asia-south1-cc-dev-sandbox-20200619.cloudfunctions.net/get_login_token';

    return this.makeLoginrequest(url, userName, password).then((result) => {
      this.setTokenValue(result.token)
      return result.token;
    });
  }

  getListOfOrganization() {
    // GET
    let url =
      'https://asia-south1-cc-dev-sandbox-20200619.cloudfunctions.net/get_quote_summary';
    return this.makeGetRequest(url).then((result) => {
      return result;
    });
  }

  getOrganizationData(orgsList) {
    //post

    console.log("orf",orgsList)
    let url =
      'https://asia-south1-cc-dev-sandbox-20200619.cloudfunctions.net/get_quote_summary';

    let requestBody = {
      "orgs": orgsList,
    };
    return this.makePostRequest(url, requestBody).then((result) => {
      return result;
    });
  }
}
